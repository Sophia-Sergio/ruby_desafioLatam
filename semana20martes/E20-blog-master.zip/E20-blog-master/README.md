## Blog para implementar CanCanCan en E20

#### Descarga este repositorio y comienza a trabajar siguiendo los videos correspondientes a la Experiencia 20.
