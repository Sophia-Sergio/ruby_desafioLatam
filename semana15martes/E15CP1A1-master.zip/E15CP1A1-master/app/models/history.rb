class History < ApplicationRecord
  mount_uploader :picture, ImageUploader
end
